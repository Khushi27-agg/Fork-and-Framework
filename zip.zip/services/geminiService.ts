import { GoogleGenAI, Type, Modality } from "@google/genai";
import { UserProfile, Recipe, CookMood } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeIngredientsFromImage(base64Data: string): Promise<string[]> {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Data, mimeType: 'image/jpeg' } },
        { text: "List every food item or ingredient you see in this image. Return them as a simple comma-separated list of names only. Be concise." }
      ]
    }
  });
  const text = response.text || "";
  return text.split(',').map(s => s.trim()).filter(Boolean);
}

export async function generateRecipe(ingredients: string[], profile: UserProfile, mood: CookMood): Promise<Recipe> {
  const prompt = `
    Create a unique recipe using these items: ${ingredients.join(', ')}.
    User Profile:
    - Diet: ${profile.diet}
    - Location: ${profile.location} (influences regional style)
    - Allergies: ${profile.allergies.join(', ') || 'None'}
    - Health: ${profile.isDiabetic ? 'Diabetic-friendly' : ''} ${profile.isLactoseIntolerant ? 'Lactose-free' : ''}
    - Mood: ${mood}

    REQUIREMENTS:
    1. STRICTLY avoid any allergens listed.
    2. Ensure sustainability in ingredient use.
    3. Include a sustainabilityScore (1-10) and sustainabilityFactor (why it's sustainable).
    4. Provide clear nutritional info.
    5. moodVibe.ambientSound should be a 2-3 word description of a background sound environment.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
          instructions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING },
                ingredientsUsed: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          nutrition: {
            type: Type.OBJECT,
            properties: {
              calories: { type: Type.NUMBER },
              protein: { type: Type.STRING },
              carbs: { type: Type.STRING },
              fats: { type: Type.STRING },
              fiber: { type: Type.STRING }
            }
          },
          sustainabilityFactor: { type: Type.STRING },
          sustainabilityScore: { type: Type.NUMBER },
          prepTime: { type: Type.STRING },
          cookTime: { type: Type.STRING },
          moodVibe: {
            type: Type.OBJECT,
            properties: { ambientSound: { type: Type.STRING } }
          },
          alternativeIngredients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                original: { type: Type.STRING },
                substitute: { type: Type.STRING },
                reason: { type: Type.STRING }
              }
            }
          }
        },
        required: ["title", "description", "ingredients", "instructions", "nutrition", "sustainabilityFactor", "sustainabilityScore", "prepTime", "cookTime", "moodVibe", "alternativeIngredients"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}

export async function chatWithAI(message: string, context?: any) {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `You are a world-class chef assistant for the app "FORK AND FRAMEWORK". Help the user with cooking questions. Context: ${JSON.stringify(context || {})}. Message: ${message}`,
    config: { tools: [{ googleSearch: {} }] }
  });
  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
}

export async function generateSpeech(text: string): Promise<string | undefined> {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Read clearly: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
      }
    }
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
}