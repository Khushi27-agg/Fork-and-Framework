import React from 'react';
import { Recipe } from '../types';

export const RecipeView: React.FC<{ recipe: Recipe; onCookMode: () => void; onBack: () => void }> = ({ recipe, onCookMode, onBack }) => {
  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
      <button onClick={onBack} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-xs uppercase tracking-widest transition-colors">
        ← Kitchen
      </button>

      <div className="bg-white rounded-[4rem] shadow-2xl overflow-hidden border border-stone-100">
        <header className="bg-stone-900 p-12 text-white flex flex-col md:flex-row justify-between items-start gap-8">
          <div className="flex-1">
            <div className="flex items-center gap-4 mb-4">
              <span className="bg-emerald-500/10 text-emerald-400 px-4 py-1.5 rounded-full border border-emerald-500/20 text-[10px] font-black uppercase tracking-widest">FORK AND FRAMEWORK Original</span>
              <div className="text-xs font-bold text-emerald-500">Score: {recipe.sustainabilityScore}/10 Eco-Efficiency</div>
            </div>
            <h1 className="text-5xl font-black serif-font mb-4">{recipe.title}</h1>
            <p className="text-stone-400 text-lg max-w-2xl italic leading-relaxed">{recipe.description}</p>
          </div>
          <div className="shrink-0 bg-white/5 backdrop-blur-xl p-8 rounded-3xl border border-white/10 text-center min-w-[160px]">
            <p className="text-6xl font-black">{recipe.nutrition.calories}</p>
            <p className="text-[10px] text-stone-500 uppercase tracking-widest font-black mt-2">Kcal Per Serving</p>
          </div>
        </header>

        <div className="p-8 md:p-12 border-b border-stone-100 grid grid-cols-2 md:grid-cols-4 gap-8 bg-stone-50/50">
          <div><p className="text-[9px] font-black text-stone-400 uppercase tracking-widest mb-1">Prep Time</p><p className="font-bold">{recipe.prepTime}</p></div>
          <div><p className="text-[9px] font-black text-stone-400 uppercase tracking-widest mb-1">Cook Time</p><p className="font-bold">{recipe.cookTime}</p></div>
          <div><p className="text-[9px] font-black text-stone-400 uppercase tracking-widest mb-1">Studio Vibe</p><p className="font-bold">{recipe.moodVibe.ambientSound}</p></div>
          <div><p className="text-[9px] font-black text-stone-400 uppercase tracking-widest mb-1">Eco Note</p><p className="font-bold text-xs">{recipe.sustainabilityFactor}</p></div>
        </div>

        <div className="p-12 md:p-20 grid grid-cols-1 lg:grid-cols-12 gap-20">
          <aside className="lg:col-span-4 space-y-12">
            <section>
              <h3 className="text-2xl font-black serif-font border-b pb-4 mb-6">Ingredients</h3>
              <ul className="space-y-4">
                {recipe.ingredients.map((ing, i) => (
                  <li key={i} className="text-stone-600 font-medium flex gap-3">
                    <span className="text-emerald-500 font-bold">•</span> {ing}
                  </li>
                ))}
              </ul>
            </section>

            {recipe.alternativeIngredients && recipe.alternativeIngredients.length > 0 && (
              <section className="bg-emerald-50/50 p-8 rounded-[2.5rem] border border-emerald-100 shadow-sm animate-in fade-in zoom-in-95 duration-500">
                <h3 className="text-[10px] font-black text-emerald-800 uppercase tracking-[0.2em] mb-6">Chef's Adaptations</h3>
                <div className="space-y-8">
                  {recipe.alternativeIngredients.map((alt, i) => (
                    <div key={i} className="relative pl-6 border-l-2 border-emerald-200 group">
                      <div className="absolute top-0 left-[-5px] w-2 h-2 rounded-full bg-emerald-400 group-hover:scale-150 transition-transform"></div>
                      <p className="text-[9px] font-black text-stone-400 uppercase tracking-widest mb-1">
                        Swap <span className="text-stone-600 line-through decoration-emerald-200/50">{alt.original}</span> for
                      </p>
                      <p className="text-emerald-900 font-black text-lg leading-none mb-2">{alt.substitute}</p>
                      <p className="text-emerald-800/60 text-xs italic leading-relaxed">{alt.reason}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </aside>

          <main className="lg:col-span-8 space-y-12">
            <h3 className="text-2xl font-black serif-font border-b pb-4">Method</h3>
            <div className="space-y-10">
              {recipe.instructions.map((step, i) => (
                <div key={i} className="flex gap-8 group">
                  <span className="shrink-0 w-12 h-12 bg-stone-100 flex items-center justify-center rounded-2xl font-black text-lg group-hover:bg-stone-900 group-hover:text-white transition-all duration-300 shadow-sm border border-stone-100">
                    {i + 1}
                  </span>
                  <div className="space-y-3 pt-2 flex-1">
                    <p className="text-stone-700 text-xl font-medium leading-relaxed">{step.text}</p>
                    <div className="flex flex-wrap gap-2">
                      {step.ingredientsUsed.map((ing, idx) => (
                        <span key={idx} className="text-[9px] font-black uppercase tracking-widest text-stone-400 bg-stone-50 px-2 py-1 rounded border border-stone-100 group-hover:border-emerald-100 group-hover:text-emerald-600 transition-colors">
                          {ing}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </main>
        </div>

        <footer className="p-12 md:p-20 bg-stone-950 flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="flex gap-12">
             <div className="text-center md:text-left"><p className="text-[10px] font-black text-stone-500 uppercase tracking-widest mb-2">Protein</p><p className="text-white font-bold text-xl">{recipe.nutrition.protein}</p></div>
             <div className="text-center md:text-left"><p className="text-[10px] font-black text-stone-500 uppercase tracking-widest mb-2">Carbs</p><p className="text-white font-bold text-xl">{recipe.nutrition.carbs}</p></div>
             <div className="text-center md:text-left"><p className="text-[10px] font-black text-stone-500 uppercase tracking-widest mb-2">Fats</p><p className="text-white font-bold text-xl">{recipe.nutrition.fats}</p></div>
          </div>
          <button onClick={onCookMode} className="w-full md:w-auto bg-emerald-500 text-stone-950 px-12 py-6 rounded-[2rem] font-black uppercase tracking-widest hover:bg-emerald-400 transition-all shadow-2xl shadow-emerald-500/20 active:scale-[0.98] flex items-center justify-center gap-3">
            <span className="text-xl">🍳</span>
            Begin Cook Mode
          </button>
        </footer>
      </div>
    </div>
  );
};
