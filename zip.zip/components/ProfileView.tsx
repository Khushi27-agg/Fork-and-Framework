import React from 'react';
import { UserProfile } from '../types';

export const ProfileView: React.FC<{ profile: UserProfile; onBack: () => void; onReset: () => void }> = ({ profile, onBack, onReset }) => {
  return (
    <div className="max-w-2xl mx-auto space-y-10 animate-in fade-in duration-500">
      <button onClick={onBack} className="text-stone-500 font-bold text-xs uppercase tracking-widest">← Back</button>
      <div className="bg-white p-12 rounded-[3rem] shadow-2xl border border-stone-100">
        <h2 className="text-4xl font-black serif-font mb-8">Chef Settings</h2>
        <div className="space-y-6">
          <div className="flex justify-between border-b pb-4">
            <span className="text-stone-400 font-bold text-xs uppercase tracking-widest">Dietary Preference</span>
            <span className="font-bold capitalize">{profile.diet}</span>
          </div>
          <div className="flex justify-between border-b pb-4">
            <span className="text-stone-400 font-bold text-xs uppercase tracking-widest">Location</span>
            <span className="font-bold">{profile.location}</span>
          </div>
          <div className="space-y-2">
            <span className="text-stone-400 font-bold text-xs uppercase tracking-widest">Active Allergies</span>
            <div className="flex flex-wrap gap-2">
              {profile.allergies.length ? profile.allergies.map(a => <span key={a} className="bg-rose-50 text-rose-700 px-3 py-1 rounded-lg text-xs font-bold border border-rose-100">{a}</span>) : <span className="text-stone-300 italic">None</span>}
            </div>
          </div>
        </div>
        <button onClick={onReset} className="mt-12 w-full py-4 border-2 border-rose-100 text-rose-500 rounded-2xl font-black uppercase tracking-widest hover:bg-rose-50 transition-all">
          Clear Studio Profile
        </button>
      </div>
    </div>
  );
};