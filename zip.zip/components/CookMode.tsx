import React, { useState, useRef, useEffect } from 'react';
import { Recipe } from '../types';
import { generateSpeech } from '../services/geminiService';

export const CookMode: React.FC<{ recipe: Recipe; onExit: () => void }> = ({ recipe, onExit }) => {
  const [stepIdx, setStepIdx] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  const stopAudio = () => {
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    setIsSpeaking(false);
  };

  const speakStep = async () => {
    stopAudio();
    const text = recipe.instructions[stepIdx]?.text;
    if (!text) return;
    setIsSpeaking(true);
    try {
      const base64 = await generateSpeech(text);
      if (base64) {
        audioContextRef.current = new AudioContext();
        const binary = atob(base64);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
        const dataInt16 = new Int16Array(bytes.buffer);
        const frameCount = dataInt16.length;
        const buffer = audioContextRef.current.createBuffer(1, frameCount, 24000);
        const channelData = buffer.getChannelData(0);
        for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i] / 32768.0;
        const source = audioContextRef.current.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContextRef.current.destination);
        source.onended = () => setIsSpeaking(false);
        source.start();
      }
    } catch {
      setIsSpeaking(false);
    }
  };

  useEffect(() => {
    speakStep();
    return stopAudio;
  }, [stepIdx]);

  return (
    <div className="fixed inset-0 bg-stone-950 z-[100] flex flex-col text-stone-100 animate-in slide-in-from-bottom duration-500">
      <header className="p-8 border-b border-stone-800 flex justify-between items-center bg-stone-900/50 backdrop-blur-xl">
        <h2 className="font-bold text-stone-100">{recipe.title}</h2>
        <button onClick={onExit} className="w-10 h-10 rounded-full bg-stone-800 flex items-center justify-center">✕</button>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-8 md:p-24 text-center">
        <p className="text-emerald-500 font-black uppercase tracking-[0.3em] mb-8 text-sm">Step {stepIdx + 1} of {recipe.instructions.length}</p>
        <p className="text-4xl md:text-6xl serif-font leading-tight mb-12 max-w-5xl">{recipe.instructions[stepIdx]?.text}</p>
        <button 
          onClick={speakStep}
          className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${isSpeaking ? 'bg-emerald-500 text-stone-900 animate-pulse' : 'bg-stone-800 text-stone-400'}`}
        >
          🔊
        </button>
      </main>

      <footer className="p-12 border-t border-stone-800 flex gap-4 bg-stone-900/50">
        <button 
          onClick={() => setStepIdx(Math.max(0, stepIdx - 1))}
          disabled={stepIdx === 0}
          className="flex-1 py-6 bg-stone-800 rounded-2xl font-bold uppercase tracking-widest disabled:opacity-20"
        >
          Previous
        </button>
        <button 
          onClick={() => stepIdx === recipe.instructions.length - 1 ? onExit() : setStepIdx(stepIdx + 1)}
          className="flex-1 py-6 bg-emerald-600 rounded-2xl font-bold uppercase tracking-widest text-stone-950"
        >
          {stepIdx === recipe.instructions.length - 1 ? 'Finish' : 'Next Step'}
        </button>
      </footer>
    </div>
  );
};