import React, { useState, useRef, useEffect } from 'react';
import { chatWithAI } from '../services/geminiService';

export const Chatbot: React.FC<{ context?: any }> = ({ context }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'bot', text: string, sources?: any[] }[]>([
    { role: 'bot', text: 'Welcome to FORK AND FRAMEWORK! I am your personal chef assistant. How can I help you in the kitchen today?' }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    const msg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: 'user', text: msg }]);
    setIsTyping(true);
    try {
      const res = await chatWithAI(msg, context);
      setMessages(prev => [...prev, { role: 'bot', text: res.text, sources: res.sources }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      {isOpen ? (
        <div className="bg-white w-[350px] h-[500px] rounded-[2.5rem] shadow-2xl border border-stone-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          <header className="bg-emerald-900 p-6 text-white flex justify-between items-center">
             <span className="font-black serif-font text-lg">Culinary Chat</span>
             <button onClick={() => setIsOpen(false)}>✕</button>
          </header>
          <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
            {messages.map((m, idx) => (
              <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-3xl text-sm ${m.role === 'user' ? 'bg-emerald-600 text-white rounded-br-none' : 'bg-stone-100 text-stone-800 rounded-bl-none'}`}>
                  {m.text}
                  {m.sources && m.sources.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-stone-200">
                      {m.sources.map((s: any, i: number) => (
                        <a key={i} href={s.web?.uri} target="_blank" className="block text-[10px] text-emerald-600 hover:underline truncate">{s.web?.title}</a>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isTyping && <div className="text-xs text-stone-400 italic">Chef is thinking...</div>}
            <div ref={scrollRef} />
          </div>
          <div className="p-4 border-t flex gap-2">
            <input type="text" placeholder="Ask chef..." className="flex-1 bg-stone-50 px-4 py-2 rounded-xl outline-none" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} />
            <button onClick={handleSend} className="bg-stone-900 text-white p-2 rounded-xl">→</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setIsOpen(true)} className="w-14 h-14 bg-emerald-900 text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform">👨‍🍳</button>
      )}
    </div>
  );
};