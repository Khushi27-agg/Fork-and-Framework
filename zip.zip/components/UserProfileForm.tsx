import React, { useState } from 'react';
import { UserProfile } from '../types';

export const UserProfileForm: React.FC<{ onComplete: (p: UserProfile) => void }> = ({ onComplete }) => {
  const [profile, setProfile] = useState<UserProfile>({
    diet: 'non-vegetarian',
    allergies: [],
    isDiabetic: false,
    isLactoseIntolerant: false,
    location: '',
  });
  const [allergyInput, setAllergyInput] = useState("");

  const addAllergy = () => {
    if (allergyInput.trim() && !profile.allergies.includes(allergyInput.trim())) {
      setProfile(p => ({ ...p, allergies: [...p.allergies, allergyInput.trim()] }));
      setAllergyInput("");
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-12 bg-white rounded-[3rem] shadow-2xl border border-stone-100 animate-in fade-in zoom-in-95 duration-700">
      <div className="text-center mb-10">
        <div className="w-16 h-16 bg-emerald-900 rounded-2xl flex items-center justify-center text-white text-3xl mx-auto mb-6 shadow-xl shadow-emerald-900/10">👨‍🍳</div>
        <h2 className="text-4xl font-black serif-font mb-4 text-stone-900">Chef's Profile</h2>
        <p className="text-stone-500 font-medium">Help us tailor your recipes to your health and regional heritage.</p>
      </div>

      <div className="space-y-8">
        <div>
          <label className="block text-[10px] font-black text-emerald-600 mb-2 uppercase tracking-widest">Regional Heritage</label>
          <input
            type="text"
            placeholder="e.g. Kyoto, Tuscany, New Delhi..."
            className="w-full px-6 py-4 rounded-2xl border border-stone-200 outline-none input-glow bg-white text-stone-800 font-medium shadow-sm"
            value={profile.location}
            onChange={e => setProfile(p => ({ ...p, location: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-[10px] font-black text-emerald-600 mb-2 uppercase tracking-widest">Dietary Style</label>
          <div className="grid grid-cols-3 gap-3">
            {['vegetarian', 'vegan', 'non-vegetarian'].map(d => (
              <button
                key={d}
                onClick={() => setProfile(p => ({ ...p, diet: d as any }))}
                className={`py-3 rounded-xl border text-xs font-bold transition-all capitalize ${profile.diet === d ? 'bg-emerald-900 text-white border-emerald-900 shadow-md' : 'bg-stone-50 text-stone-500 border-stone-100'}`}
              >
                {d.replace('-', ' ')}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black text-emerald-600 mb-2 uppercase tracking-widest">Health & Allergies</label>
          <div className="flex flex-wrap gap-4 mb-4">
            <label className="flex items-center gap-2 text-sm font-bold text-stone-700 cursor-pointer">
              <input type="checkbox" className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500" checked={profile.isDiabetic} onChange={e => setProfile(p => ({ ...p, isDiabetic: e.target.checked }))} /> Diabetic Friendly
            </label>
            <label className="flex items-center gap-2 text-sm font-bold text-stone-700 cursor-pointer">
              <input type="checkbox" className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500" checked={profile.isLactoseIntolerant} onChange={e => setProfile(p => ({ ...p, isLactoseIntolerant: e.target.checked }))} /> Lactose Free
            </label>
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add allergy (e.g. Shellfish)"
              className="flex-1 px-4 py-2 rounded-xl border border-stone-200 outline-none bg-white text-stone-800 font-medium shadow-sm input-glow"
              value={allergyInput}
              onChange={e => setAllergyInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addAllergy()}
            />
            <button onClick={addAllergy} className="px-6 bg-stone-900 text-white rounded-xl text-xs font-bold hover:bg-emerald-900 transition-colors">Add</button>
          </div>
          <div className="flex flex-wrap gap-2 mt-4">
            {profile.allergies.map(a => (
              <span key={a} className="bg-rose-50 text-rose-700 px-3 py-1 rounded-lg text-xs font-black border border-rose-100 flex items-center gap-2 animate-in zoom-in">
                {a} <button onClick={() => setProfile(p => ({ ...p, allergies: p.allergies.filter(i => i !== a) }))}>×</button>
              </span>
            ))}
          </div>
        </div>

        <button
          onClick={() => onComplete(profile)}
          disabled={!profile.location.trim()}
          className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 disabled:opacity-20 transition-all active:scale-[0.98] hover:bg-emerald-500"
        >
          Initialize Studio
        </button>
      </div>
    </div>
  );
};