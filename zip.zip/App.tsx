import React, { useEffect, useState } from "react";
import { UserProfile, AppMode, Recipe, CookMood } from "./types";
import { UserProfileForm } from "./components/UserProfileForm";
import { RecipeView } from "./components/RecipeView";
import { CookMode } from "./components/CookMode";
import { ProfileView } from "./components/ProfileView";
import { Chatbot } from "./components/Chatbot";
import { generateRecipe, analyzeIngredientsFromImage } from "./services/geminiService";

const MOODS: { id: CookMood; label: string; icon: string }[] = [
  { id: "quick", label: "Quick", icon: "⚡" },
  { id: "gourmet", label: "Gourmet", icon: "✨" },
  { id: "comfort", label: "Comfort", icon: "🥘" },
  { id: "light", label: "Light", icon: "🥗" },
];

const App: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem("ff_profile");
    return saved ? JSON.parse(saved) : null;
  });

  const [mode, setMode] = useState<AppMode>(() => 
    localStorage.getItem("ff_profile") ? AppMode.Dashboard : AppMode.Onboarding
  );

  const [ingredientsText, setIngredientsText] = useState("");
  const [basket, setBasket] = useState<string[]>([]);
  const [mood, setMood] = useState<CookMood>("quick");
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  const handleProfileComplete = (p: UserProfile) => {
    setProfile(p);
    localStorage.setItem("ff_profile", JSON.stringify(p));
    setMode(AppMode.Dashboard);
  };

  const handleAddIngredients = () => {
    if (!ingredientsText.trim()) return;
    const items = ingredientsText.split(/[,|\n]/).map(i => i.trim()).filter(Boolean);
    setBasket(prev => [...new Set([...prev, ...items])]);
    setIngredientsText("");
  };

  const handleImageScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsScanning(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const base64 = (reader.result as string).split(",")[1];
        const items = await analyzeIngredientsFromImage(base64);
        setBasket(prev => [...new Set([...prev, ...items])]);
      } catch {
        alert("Scan failed. Try adding manually.");
      } finally {
        setIsScanning(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async () => {
    if (!profile || basket.length === 0) return;
    setIsGenerating(true);
    try {
      const res = await generateRecipe(basket, profile, mood);
      setRecipe(res);
      setMode(AppMode.RecipeView);
    } catch {
      alert("Chef is busy. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 pb-20">
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200 py-4 px-6 flex justify-between items-center">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => profile && setMode(AppMode.Dashboard)}>
          <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg shrink-0">🍴</div>
          <div className="flex flex-col">
            <h1 className="text-xl font-black serif-font text-stone-900 tracking-tighter uppercase leading-none">Fork and Framework</h1>
            <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mt-1">where ideas meet flavor</span>
          </div>
        </div>
        {profile && (
          <button onClick={() => setMode(AppMode.Profile)} className="w-9 h-9 rounded-full bg-stone-900 text-white text-xs font-bold border-2 border-white shadow-sm">
            {profile.location.charAt(0).toUpperCase()}
          </button>
        )}
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {mode === AppMode.Onboarding && <UserProfileForm onComplete={handleProfileComplete} />}
        
        {mode === AppMode.Dashboard && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 animate-in fade-in duration-500">
            <div className="lg:col-span-7 space-y-8">
              <section>
                <h2 className="text-4xl font-black serif-font mb-2">My Pantry</h2>
                <p className="text-stone-500 mb-6 font-medium">Type items or scan your ingredients for AI inspiration.</p>
                <div className="relative">
                  <textarea
                    className="w-full h-44 p-6 rounded-3xl border border-stone-200 bg-white shadow-sm focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all resize-none"
                    placeholder="2 eggs, flour, spinach..."
                    value={ingredientsText}
                    onChange={(e) => setIngredientsText(e.target.value)}
                  />
                  <div className="absolute bottom-4 right-4 flex gap-2">
                    <label className="p-3 rounded-xl bg-white border border-stone-200 text-stone-600 hover:bg-emerald-50 cursor-pointer transition-colors shadow-sm" title="Scan Image">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                      <input type="file" accept="image/*" hidden onChange={handleImageScan} />
                    </label>
                    <button onClick={handleAddIngredients} className="px-6 py-3 rounded-xl bg-stone-900 text-white font-bold text-sm hover:bg-stone-800 transition-colors shadow-lg">Add Items</button>
                  </div>
                  {isScanning && (
                    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm rounded-3xl flex items-center justify-center z-10">
                      <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  )}
                </div>
              </section>

              <section>
                <h3 className="text-2xl font-black serif-font mb-4">Cooking Mood</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {MOODS.map(m => (
                    <button key={m.id} onClick={() => setMood(m.id)} className={`p-4 rounded-2xl border-2 transition-all ${mood === m.id ? 'border-emerald-500 bg-emerald-50' : 'border-stone-100 bg-white hover:border-emerald-100'}`}>
                      <div className="text-2xl mb-2">{m.icon}</div>
                      <p className="text-xs font-bold uppercase tracking-widest">{m.label}</p>
                    </button>
                  ))}
                </div>
              </section>
            </div>

            <div className="lg:col-span-5">
              <div className="bg-white rounded-[2.5rem] p-8 shadow-xl border border-stone-100 h-full flex flex-col">
                <h3 className="text-2xl font-black serif-font mb-6 flex items-center gap-3">
                  <span className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-lg">🧺</span> Basket
                </h3>
                <div className="flex-1 bg-stone-50 rounded-2xl p-4 mb-6 overflow-y-auto max-h-[300px] border border-stone-100 custom-scrollbar">
                  {basket.length === 0 ? (
                    <p className="text-stone-400 text-sm text-center py-10 italic">Your ingredient basket is empty.</p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {basket.map(i => (
                        <span key={i} className="px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-bold text-stone-700 flex items-center gap-2 group cursor-pointer hover:border-rose-200" onClick={() => setBasket(prev => prev.filter(item => item !== i))}>
                          {i} <span className="text-stone-300 group-hover:text-rose-500">×</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <button
                  disabled={isGenerating || basket.length === 0}
                  onClick={handleGenerate}
                  className="w-full py-5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-widest shadow-lg shadow-emerald-600/20 disabled:opacity-50 transition-all"
                >
                  {isGenerating ? "Cooking ideas..." : "Generate Recipe"}
                </button>
              </div>
            </div>
          </div>
        )}

        {mode === AppMode.RecipeView && recipe && (
          <RecipeView recipe={recipe} onCookMode={() => setMode(AppMode.CookMode)} onBack={() => setMode(AppMode.Dashboard)} />
        )}
        
        {mode === AppMode.CookMode && recipe && (
          <CookMode recipe={recipe} onExit={() => setMode(AppMode.RecipeView)} />
        )}

        {mode === AppMode.Profile && profile && (
          <ProfileView profile={profile} onBack={() => setMode(AppMode.Dashboard)} onReset={() => { localStorage.clear(); location.reload(); }} />
        )}
      </main>

      {mode !== AppMode.CookMode && <Chatbot context={recipe || { basket, profile }} />}
    </div>
  );
};

export default App;